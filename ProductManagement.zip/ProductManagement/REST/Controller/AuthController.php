<?php
require_once("../Handler/AuthRestHandler.php");
header("Access-Control-Allow-Origin: *");	

$action = "";
if(isset($_GET["action"]))
	$action = $_GET["action"];

	switch($action){
		case "login":
			$loginRestHandler = new AuthRestHandler();
			$loginRestHandler->login();
			break;
			
		case "logout":
			$loginRestHandler = new AuthRestHandler();
			$loginRestHandler->logout();
			break;
	
		case "" :
			//404 - not found;
			break;
	}
	

	

?>
