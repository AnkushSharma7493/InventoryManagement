<?php
require_once("../Handler/ProductTransactionRestHandler.php");
require_once("FrontController.php");
require_once("../DAO/ProductTransactionDAO.php");
header("Access-Control-Allow-Origin: *");	



$json = file_get_contents('php://input');
$request = json_decode($json);
$productTransactionRestHandler = new ProductTransactionRestHandler();
$productTransactiondao =new ProductTransactionDAO();
$tokenizer = new FrontController();

$action = "";
if(isset($_GET["action"]))
	$action = $_GET["action"];

//verify api token 
if($tokenizer->verifyToken($productTransactiondao,$request))
{	
	switch($action)
	{
		case "READ":	$productTransactionRestHandler->getItems($productTransactiondao,$request);
						break;

		case "ADD":	 	$productTransactionRestHandler->addItem($productTransactiondao,$request);
						break;

		case "MODIFY":	$productTransactionRestHandler->updateItem($productTransactiondao,$request);
						break;
						
		case "READIN":	$productTransactionRestHandler->getProductTransactionForInward($productTransactiondao,$request);
						break;
		
		case "READOUT":	$productTransactionRestHandler->getProductTransactionForOutward($productTransactiondao,$request);
						break;
						
		case "READMAX":	$productTransactionRestHandler->getMaxProcessID($productTransactiondao,$request);
						break;	

		case "READCOM":	$productTransactionRestHandler->getCompletedProcessID($productTransactiondao,$request);
						break;	
		
		case "READSTGPRD":	$productTransactionRestHandler->getProductTransactionByState($productTransactiondao,$request);
							break;	

		case "READFILT"	:	$productTransactionRestHandler->getProductTransactionByFilter($productTransactiondao,$request);
							break;	
		
		case "SALE"		:	$productTransactionRestHandler->SaleProducts($productTransactiondao,$request);
							break;	
		
		case "COUNT"	:	$productTransactionRestHandler->getProductTransactionCount($productTransactiondao,$request);
							break;	

	}
}

?>