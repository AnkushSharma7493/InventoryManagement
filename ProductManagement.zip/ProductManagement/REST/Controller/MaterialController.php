<?php
require_once("../Handler/MaterialRestHandler.php");
require_once("FrontController.php");
header("Access-Control-Allow-Origin: *");	


$json = file_get_contents('php://input');
$request = json_decode($json);
$materialRestHandler = new MaterialRestHandler();
$materialdao =new MaterialDAO();
$tokenizer = new FrontController();

$action = "";
if(isset($_GET["action"]))
	$action = $_GET["action"];

//verify api token 
if($tokenizer->verifyToken($materialdao,$request))
{	
	switch($action)
	{
		case "READ":	$materialRestHandler->getItems($materialdao,$request);
						break;		

		case "ADD":	 	$materialRestHandler->addItem($materialdao,$request);
						break;

		case "MODIFY":	$materialRestHandler->updateItem($materialdao,$request);
						break;

		case "REMOVE":	$materialRestHandler->deleteItem($materialdao,$request);
						break;
	}
}

?>