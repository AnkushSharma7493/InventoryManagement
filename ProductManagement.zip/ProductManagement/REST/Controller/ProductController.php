<?php
require_once("../Handler/ProductRestHandler.php");
require_once("FrontController.php");
header("Access-Control-Allow-Origin: *");	


$json = file_get_contents('php://input');
$request = json_decode($json);
$productRestHandler = new ProductRestHandler();
$productdao =new ProductDAO();
$tokenizer = new FrontController();

$action = "";
if(isset($_GET["action"]))
	$action = $_GET["action"];

//verify api token 
if($tokenizer->verifyToken($productdao,$request))
{	
	switch($action)
	{
		case "READ":	$productRestHandler->getItems($productdao,$request);
						break;		

		case "ADD":	 	$productRestHandler->addItem($productdao,$request);
						break;

		case "MODIFY":	$productRestHandler->updateItem($productdao,$request);
						break;

		case "REMOVE":	$productRestHandler->deleteItem($productdao,$request);
						break;

		default : 		break;
	}
}

?>