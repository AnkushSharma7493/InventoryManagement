<?php
require_once("../Handler/CostCenterRestHandler.php");
require_once("FrontController.php");
header("Access-Control-Allow-Origin: *");	


$json = file_get_contents('php://input');
$request = json_decode($json);
$ccRestHandler = new CostCenterRestHandler();
$costCenterdao =new CostCenterDAO();
$tokenizer = new FrontController();

$action = "";
if(isset($_GET["action"]))
	$action = $_GET["action"];

//verify api token 
if($tokenizer->verifyToken($costCenterdao,$request))
{	
	switch($action)
	{
		case "READ":	$ccRestHandler->getItems($costCenterdao,$request);
						break;		

		case "ADD":	 	$ccRestHandler->addItem($costCenterdao,$request);
						break;

		case "MODIFY":	$ccRestHandler->updateItem($costCenterdao,$request);
						break;

		case "REMOVE":	$ccRestHandler->deleteItem($costCenterdao,$request);
						break;
	}
}

?>