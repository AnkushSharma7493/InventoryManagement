<?php
require_once("../Handler/UserRestHandler.php");
require_once("FrontController.php");
header("Access-Control-Allow-Origin: *");	


$json = file_get_contents('php://input');
$request = json_decode($json);
$userRestHandler = new UserRestHandler();
$userdao =new UserDAO();
$tokenizer = new FrontController();

$action = "";
if(isset($_GET["action"]))
	$action = $_GET["action"];

//verify api token 
if($tokenizer->verifyToken($userdao,$request))
{	
	switch($action)
	{
		case "READ":	$userRestHandler->getAllUsers($userdao,$request);
						break;		

		case "ADD":	 	$userRestHandler->addNewUser($userdao,$request);
						break;

		case "MODIFY":	$userRestHandler->updateUser($userdao,$request);
						break;

		case "REMOVE":	$userRestHandler->deleteUser($userdao,$request);
						break;
	}
}

?>