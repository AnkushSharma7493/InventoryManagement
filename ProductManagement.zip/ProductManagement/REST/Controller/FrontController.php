<?php
require_once("../Handler/SimpleRest.php");

Class FrontController extends SimpleRest
{
    function verifyToken($dao,$request)
    {
        $response = new BaseResponse();
        if(!is_null($dao->verifyToken($request->api_key)))
        {	
            return true;
        }
        else
        {
            $response->status=$this->setResponseCode(401);
            $response->api_key=$request->api_key;
            $response->role=$request->role;
            $json = json_encode($response);
            echo $json;
            exit;
        }
    }
}

?>