<?php
/* 
A domain Class to demonstrate RESTful web services
*/
Class BaseResponse {
	public $api_key;
	public $role;
	public $status;
}
?>