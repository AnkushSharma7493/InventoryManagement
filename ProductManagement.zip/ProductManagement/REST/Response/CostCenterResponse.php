<?php

Class CostCenterResponse
{
    public $ccid;
    public $ccname;
    public $stages=array();
    public $products=array();
}
?>