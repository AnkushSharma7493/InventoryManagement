<?php
require_once("BaseResponse.php");

Class Response extends BaseResponse
{
    public $data;
}

?>