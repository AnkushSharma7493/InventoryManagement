<?php
require_once("Connect.php");
require_once("CommonDAO.php");
require_once("ProductDAO.php");
require_once("StageDAO.php");
require_once("../Response/Reference.php");

Class CostCenterDAO extends CommonDAO
{
	public function addItem($costCenter)
	{     
       $sql="insert into $this->costcenterTable values(NULL,'$costCenter->ccName')";
       $costCenter->ccid =  $this->executeInsertQuery($sql);   
       return $costCenter;
	}
	
	public function updateItem($costCenter)
	{
        $sql="update $this->costcenterTable
                set name='$costCenter->ccName'
                where id='$costCenter->ccid'";

        return $this->executeQuery($sql);   
	}
    
    
    public function deleteItem($costcenter)
    {
       $sql="delete from $this->costcenterTable where id='$costcenter->ccid'";
       return $this->executeQuery($sql);   
    }

	public function getCC($customerQuery)
	{
		$connect=new Connection();
        $connection=$connect->getConnection();
        $dao=array();

        $sql="SELECT id,name FROM $this->costcenterTable";
        
        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }

        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $dao[$index]=array('ccName'=>$row['name'],
                                        'ccId'=>$row['id']
                                        );
                    $index++;
                }
            }
        }
        $connection->close();
        return $dao;
    }
    
    public function getCostCenterView()
    {
        $dao=array();
        $ccs = $this->getCC(null);
        $index=0;
        $stagedao=new StageDAO(); 
        $productdao=new ProductDAO(); 
        foreach($ccs as $i => $cc) 
        {
            $data=new Reference();
            $cid=$ccs[$i]['ccId'];
            
            $Stage_query="SELECT * FROM $this->stageTable s join $this->costcenterTable c on s.ccid=c.id where c.id=$cid";
            $data->stages=$stagedao->getStages($Stage_query);
            
            $Product_query="SELECT * FROM  $this->costcenterTable c join $this->productTable p on p.ccid=c.id where c.id=$cid";
            $data->products=$productdao->getProducts($Product_query);
            
            $data->ccid = $ccs[$i]['ccId'];
            $data->ccName=$ccs[$i]['ccName'];
            $dao[$index]=$data;
            $index++;
        }
        return $dao;
    }

    public function addCostCenterView($costcenter)
    {
        //save cost center
        if($costcenter=$this->addItem($costcenter))
        {       
        $stageDAO = new StageDAO();
        foreach($costcenter->stages as $i => $stage)
        {
            $stage->sequence=$i+1;
            $stage->ccid=$costcenter->ccid;
            $stage->stageid=$stageDAO->addItem($stage);
        }
        return $costcenter;
        }
        else{
            return false;
        }
    }

    public function updateCostCenterView($costcenter)
    {
        if($this->updateItem($costcenter))
        {
            $stageDAO = new StageDAO();
            foreach($costcenter->stages as $stage)
            {
                if($stage->stageid==null)
                {
                    $stageDAO->addItem($stage);
                }
                else
                {
                    $stageDAO->updateItem($stage);
                }
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    public function deleteCostCenterView($costcenter)
    {
        if($this->deleteItem($costcenter))
        {
            $stageDAO = new StageDAO();
            foreach($costcenter->stages as $stage)
            {
                $stageDAO->deleteItem($stage);
            }
            return true;
        }
        else
        {
            return false;
        }
    }
}

?>



