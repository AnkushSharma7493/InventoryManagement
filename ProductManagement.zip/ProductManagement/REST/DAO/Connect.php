<?php
Class Connection
{
    protected $DB_HOST="localhost";
    protected $DB_USER="angrykcy_sethiinventory";
    protected $DB_PASS="Dexter@123@";
    protected $DB_NAME="sethengineering";

    public function getConnection()
    {
    //$connect = mysqli_connect("localhost" ,"root","root","sethiinventory");
    $connect = mysqli_connect("localhost" ,"elechifj_sethiinventory","sethiinventory123","elechifj_sethiinventory");
   
    mysqli_set_charset($connect, "utf8");
    if ($connect->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        return NULL;
    } 
    return $connect;
    }
}
?>