<?php
require_once("Connect.php");
require_once("CommonDAO.php");

Class UserDAO extends CommonDAO
{
    public function getCredentails($userName)
    {
        $connect=new Connection();
        $connection=$connect->getConnection();

        $sql="SELECT UserPassword,role,loginStatus FROM $this->userDetailsTable where UserName='".$userName."'";
	 
        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
				$row = mysqli_fetch_assoc($result);
			    $dao = array('password'=>$row['UserPassword'],
                            'role'=>$row['role'],
                            'loginStatus'=>$row['loginStatus']
                            );

				$connection->close();
                return $dao;
            }
        }
        $connection->close();
        return NULL;
    }

    /** LOGGED OUT  */
    public function setStatus($key,$status,$userName)
    {
        $connect=new Connection();
        $connection=$connect->getConnection();
        $res=false;
        $sql="update $this->userDetailsTable 
                set ApiKey='$key',
                loginStatus='$status',
                lastLogin=sysdate()
                where UserName='$userName'";

       if(!($result = mysqli_query($connection,$sql)))
       {
           throw new Exception("Exception while generating token");
       }
       $connection->close();
    }

    public function setLogin($userName)
    {
        $key="";
        $i=0;
        while($i < 20)
        {
            $key=$key.mt_rand(0, 9);
            $i++;
        }
        $this->setStatus($key,'LOGGEDIN',$userName);
        return $key;
    }
	
	public function addUser($user)
	{
        //$user->UserPassword=password_hash($user->UserPassword, PASSWORD_DEFAULT);
	    $sql="insert into $this->userDetailsTable values(NULL,'$user->UserName','$user->UserPassword',sysdate(),'$user->role','ACTIVE','','LOGGEDOFF')";
        $user->Userid = $this->executeInsertQuery($sql);
        $user->loginStatus ='LOGGEDOFF';
        return $user;
    }

	public function updateUser($user)
	{     
        $sql="update $this->userDetailsTable 
                set UserName='$user->UserName',
                UserPassword='$user->UserPassword',
                role='$user->role'
                where Userid='$user->Userid'";
        return $this->executeQuery($sql);   
	}
    
    function deleteUser($user)
    {
       $sql="delete from $this->userDetailsTable where Userid=$user->Userid";
       return $this->executeQuery($sql);   
    }

	public function getUsers($customerQuery)
	{
		$connect=new Connection();
        $connection=$connect->getConnection();
        $users=array();

        $sql="SELECT * FROM $this->userDetailsTable";
        
        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }
	 
        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $users[$index]=array('Userid'=>$row['Userid'],
                                        'UserName'=>$row['UserName'],
                                        'UserPassword'=>$row['UserPassword'],
                                        'lastLogin'=>$row['lastLogin'],
                                        'role'=>$row['role'],
                                        'loginStatus'=>$row['loginStatus']
                                        );
                    $index++;
                }
            }
        }
        $connection->close();
        return $users;
	}
}

?>
