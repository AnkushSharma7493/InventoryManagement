<?php
require_once("Connect.php");
require_once("CommonDAO.php");

Class MatProdMapDAO extends CommonDAO
{
    public function addItem($mid,$pid,$munit)
	{
	    $sql="insert into $this->matProdMapTable value(null,$mid,$pid,$munit)";
        return $this->executeInsertQuery($sql);
    }

    function deleteItem($mapid)
    {
       $sql="delete from $this->matProdMapTable where mapid=$mapid";
       return $this->executeQuery($sql);   
    }

	public function getItems($customerQuery)
	{
		$connect=new Connection();
        $connection=$connect->getConnection();
        $matprod=array();

        $sql="SELECT * FROM $this->matProdMapTable";
        
        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }
	 
        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $matprod[$index]=array('mapid'=>$row['mapid'],
                                        'materialid'=>$row['materialid'],
                                        'productid'=>$row['productid']);
                    $index++;
                }
            }
        }
        $connection->close();
        return $matprod;
	}
}
?>