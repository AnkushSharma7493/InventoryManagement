<?php

require_once("Connect.php");
require_once("CommonDAO.php");
require_once("MaterialDAO.php");
require_once("../Response/Reference.php");

Class ProductTransactionDAO extends CommonDAO{

    public function getProductTransactions($customerQuery){
		$connect=new Connection();
        $connection=$connect->getConnection();
        $dao=array();
        //put limit 100 on query
        $sql="SELECT * FROM $this->productTransactionTable t join $this->productTable p on t.productid=p.productid 
                join $this->costcenterTable c on c.id=t.ccid join $this->stageTable s on s.stageid = t.stateid order by transactionid desc ";

        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }
        
        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $dao[$index]=array('transid'=>$row['transactionid'],
                                        'processid'=>$row['processid'],
                                        'ccid'=>$row['ccid'],
                                        'productid'=>$row['productid'],
                                        'inquantity'=>$row['in_quantity'],
                                        'outquantity'=>$row['out_quantity'],
                                        'state'=>$row['stateid'],
                                        'ccname'=>$row['name'],
                                        'productname'=>$row['productname'],
                                        'stagename'=>$row['stageName'],
                                        'sequence'=>$row['sequence'],
                                        'date'=>$row['date'],
                                        'status'=>$row['status'],
                                        'type'=>$row['type'],
                                        'gatepass'=>$row['Gatepass'],
                                        'billNo'=>$row['BillNumber'],
                                        'Challan'=>$row['ChallanNo'],
                                        'bounty'=>$row['BuiltyNumber'],
                                        'transporter'=>$row['TransporterName'],
                                        'courierNo'=>$row['CourierVendor'],
                                        'courierVendor'=>$row['CourierNumber']
                                        );
                    $index++;
                }
            }
        }
        $connection->close();
        return $dao;
    
    }

    public function addItem($productTransaction)
    {
        $res = array(); 
        $i=0;
          // Get Material by SQL
          $sql =    "SELECT r.instock_unit,r.materialid,m.materialQtyPerProduct as unit_weight,1 as materialname,1 as shape ,1 as length, 1 as width, 1 as height, 1 as radius,1 as measurement_unit
                    FROM $this->rawMaterial r join $this->matProdMapTable m on r.materialid=m.materialid 
                    join $this->productTable p on p.productid=m.productid where p.productid=$productTransaction->productid"; 

          $materialDAO = new MaterialDAO();
          $material=$materialDAO->getMaterials($sql);
          $unit=0;
          $mid=0;
          $materialPerUnit=0;
          $materialStockFlag=true;

        if($productTransaction->processid==0)
        {
            // verify if we have sufficent stock available for each require material
            foreach($material as $mat)
            {
                $unit=$mat['instock_unit'];
                $mid=$mat['id'];
                $materialPerUnit=$mat['unit_weight']; //This is materialQtyPerProd mapped with unit_weight for convience
                
                $requeriedMatrialForSlot = $productTransaction->inquantity*$materialPerUnit;
  
                if($unit<$requeriedMatrialForSlot)
                {
                      $materialStockFlag=false;
                      break;
                }
            }

            // if all material stock available for input request
            if($materialStockFlag)
            {
                // add transaction into system,
                $pid = $this->addTransaction($productTransaction);

                // update each material stock in DB
                foreach($material as $mat)
                {
                    $unit=$mat['instock_unit'];
                    $mid=$mat['id'];
                    $materialPerUnit=$mat['unit_weight'];
                    $requeriedMatrialForSlot = $productTransaction->inquantity*$materialPerUnit;
                    $res[$i]=$requeriedMatrialForSlot;
                    $i++;
                    $unit = $unit-$requeriedMatrialForSlot;
                    $sql =  "update raw_material set instock_unit='$unit' where materialid='$mid'";
                    $this->executeQuery($sql);  
                }
            }
            else
            {
                // return response with message : insufficient material available in stock
                return false;
            }
            return  $pid;
          //return true;
          
        }
        else
        {
            if($productTransaction->outquantity<=$productTransaction->inquantity)
            {
                $diff = $productTransaction->inquantity-$productTransaction->outquantity;
             
                //if out quantity is greater 
                if($diff!=0)
                {
                    foreach($material as $mat)
                    {
                        $unit=$mat['instock_unit'];
                        $mid=$mat['id'];
                        $materialPerUnit=$mat['unit_weight'];
                        $extraSlot = $diff*$materialPerUnit;
                        $unit = $unit+$extraSlot;
                        $sql =  "update raw_material set instock_unit='$unit' where materialid='$mid'";
                        $this->executeQuery($sql);  
                    }
                }
                //add transaction into system,
                $pid = $this->addTransaction($productTransaction);
            }
            else
            {   
                // put check at UI, so no greater quantity could be sent for out_quantity
                return false;
            }
            return true;
            //return $res;
        }
    }

    public function addTransaction($productTransaction)
	{
        // start trasaction have processid = 0 and transid =0 and status = INPROGRESS
        // verify material stock availablity
        // This part updates the income transaction status from inprogress to complete and update the out quantity
        // if status is 'complete' implies the product completed its life cycle and set status to completed
       $s="";
        if($productTransaction->transid>0)
        {
            $status="COMPLETE";

            if($productTransaction->status=="COMPLETE")
            {
                $status="COMPLETED";
            }

            $sql="update $this->productTransactionTable set status='$status', out_quantity=$productTransaction->outquantity where transactionid=$productTransaction->transid";
            $this->executeQuery($sql);  

            // this transaction is pointing to prcess next step, below logic is adjusting inputquantity of next step euqals out quantity of current step
            $productTransaction->inquantity=$productTransaction->outquantity;
        }
        
        if($productTransaction->status!="COMPLETE")
        {
            $sql="insert into $this->productTransactionTable value(null,$productTransaction->processid,$productTransaction->ccid,$productTransaction->productid,$productTransaction->inquantity,'0','$productTransaction->Challan','$productTransaction->gatepass',null,null,null,null,null,'$productTransaction->stateid','$productTransaction->status',sysdate())";
            $pid =  $this->executeInsertQuery($sql);
            $s=$sql;
        }
        else
        {
            $pid="TransactionCompleted";
        }

        
        if($productTransaction->processid==0)
        {
            $sql="update $this->productTransactionTable set processid=$pid where transactionid=$pid";
            $this->executeQuery($sql);   
            
        }
        //return $pid;
        return $s;
    }

    public function SaleProducts($productTransaction)
	{	
		// subtract the outQuantity unit from transaction where transid and processid
        $diff = $productTransaction->inquantity-$productTransaction->outquantity;
        $sql="update $this->productTransactionTable set out_quantity=$diff where transactionid=$productTransaction->transid and status='COMPLETED'";
        $this->executeQuery($sql);  

        // add into system
        $sql="insert into $this->productTransactionTable value(null,$productTransaction->processid,$productTransaction->ccid,$productTransaction->productid,$diff,$productTransaction->outquantity,null,'$productTransaction->gatepass','$productTransaction->billNumber',null,null,null,null,'1','$productTransaction->status',sysdate())";
        $pid =  $this->executeInsertQuery($sql);
       return $pid;
    }
    
    public function updateItem($productTransaction)
	{
        $sql="update $this->productTransactionTable 
        set in_quantity='$productTransaction->inquantity',
        out_quantity='$productTransaction->outquantity',
        GatePass='$productTransaction->gatepass',
        ChallanNo='$productTransaction->Challan',
        BuiltyNumber='$productTransaction->bounty',
        TransporterName='$productTransaction->transporter',
        CourierNumber='$productTransaction->courierNo',
        CourierVendor='$productTransaction->courierVendor' 
        where transactionid='$productTransaction->transid'";
        return $this->executeQuery($sql);   
	}
    
    public function getProductTransactionForInward($cid)
    {
        $sql="SELECT * FROM $this->productTransactionTable t join $this->productTable p on t.productid=p.productid 
        join $this->costcenterTable c on c.id=t.ccid join $this->stageTable s on s.stageid = t.stateid and s.type='INWARD' where t.ccid=$cid and t.status='INPROGRESS' order by transactionid desc ";
        return $this->getProductTransactions($sql);
    }
    
    public function getProductTransactionForOutward($cid)
    {
        $sql="SELECT * FROM $this->productTransactionTable t join $this->productTable p on t.productid=p.productid 
        join $this->costcenterTable c on c.id=t.ccid join $this->stageTable s on s.stageid = t.stateid and s.type='OUTWARD' where t.ccid=$cid and t.status='INPROGRESS' order by transactionid desc ";
        return $this->getProductTransactions($sql);
    }

    public function getCompletedProcessID($cid)
    {
        $sql="SELECT * FROM $this->productTransactionTable t join $this->productTable  p on t.productid=p.productid 
        join $this->costcenterTable c on c.id=t.ccid join $this->stageTable s on s.stageid = t.stateid where t.ccid=$cid and t.status = 'COMPLETED' and t.out_quantity>0 order by transactionid desc ";
        return $this->getProductTransactions($sql);
    }

    public function getProductTransactionByState($cid,$state)
    {
        //limit $this->limit
        $sql="SELECT * FROM $this->productTransactionTable t join $this->costcenterTable c on c.id=t.ccid join $this->productTable p on t.productid=p.productid  
        join $this->stageTable s on s.stageid = t.stateid where t.ccid=$cid and s.stageid=$state and t.status='INPROGRESS' order by transactionid desc";
        return $this->getProductTransactions($sql);
    }

    public function getProductTransactionByFilters($cid,$prd,$state,$startDate,$endDate)
    {
        $firstCondition=false;

        $sql="SELECT * FROM $this->productTransactionTable t join $this->costcenterTable c on c.id=t.ccid join $this->productTable p on t.productid=p.productid  
        join $this->stageTable s on s.stageid = t.stateid";
        
        if($cid!=-1)
        {
            if($firstCondition==false)
            {   
                $firstCondition=true;
                $sql=$sql." where";
            }
            else
            {
                $sql=$sql." and";
            }
            $sql.=" t.ccid=$cid";
        }

        if($prd!=-1)
        {
            if($firstCondition==false)
            {
                $firstCondition=true;
                $sql=$sql." where";
            }
            else
            {
                $sql=$sql." and";
            }
            $sql.=" t.productid=$prd";
        }
      
        if($state!=-1)
        {
            if($firstCondition==false)
            {
                $firstCondition=true;
                $sql=$sql." where";
            }
            else
            {
                $sql=$sql." and";
            }
            $sql.=" t.stateid=$state";
        }

        if($startDate!=-1 && $endDate!=-1)
        {
            if($firstCondition==false)
            {
                $firstCondition=true;
                $sql=$sql." where";
            }
            else
            {
                $sql=$sql." and";
            }
            $sql.=" DATE(date) BETWEEN '$startDate' AND '$endDate'";
        }
       else if($startDate==-1 && $endDate!=-1)
        {
            if($firstCondition==false)
            {
                $firstCondition=true;
                $sql=$sql." where";
            }
            else
            {
                $sql=$sql." and";
            }
            $sql.=" DATE(date) <= '$endDate'";
        }
       else if($startDate!=-1 && $endDate==-1)
        {
            if($firstCondition==false)
            {
                $firstCondition=true;
                $sql=$sql." where";
            }
            else
            {
                $sql=$sql." and";
            }
            $sql.=" DATE(date) >= 'startDate'";
        }

        $sql=$sql." order by transactionid desc  ";
       return $this->getProductTransactions($sql);
    }

    // counter function
    public function getProductTransactionCount($type)
    {
        $connect=new Connection();
        $connection=$connect->getConnection();
        //put limit 100 on query
       $sql="SELECT count(*) as count FROM $this->productTransactionTable t join $this->productTable p on t.productid=p.productid 
                join $this->costcenterTable c on c.id=t.ccid join $this->stageTable s on s.stageid = t.stateid 
                where s.type='$type' and t.status='INPROGRESS' order by transactionid desc";
		$dao=array();
       
        
        if($result = mysqli_query($connection,$sql))
		{
			 if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
				 $dao[$index]=array('count'=>$row['count']);
				  $index++;
                }
            }
		}
		 $connection->close();
       return $dao;
    }

    public function getFinishedCount()
    {
        $connect=new Connection();
        $connection=$connect->getConnection();
        //put limit 100 on query
        $sql="SELECT SUM(OUT_QUANTITY) as count FROM $this->productTransactionTable t join $this->productTable p on t.productid=p.productid 
        join $this->costcenterTable c on c.id=t.ccid join $this->stageTable s on s.stageid = t.stateid 
         where  t.status='COMPLETED' order by transactionid desc";
		$dao=array();
       
        
        if($result = mysqli_query($connection,$sql))
		{
			 if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
				 $dao[$index]=array('count'=>$row['count']);
				  $index++;
                }
            }
		}
		 $connection->close();
       return $dao;
    }
}
?>
