<?php
require_once("Connect.php");
require_once("CommonDAO.php");

Class StageDAO extends CommonDAO
{
	public function addItem($stage)
	{
	    $sql="insert into $this->stageTable values(NULL,'$stage->stageName','$stage->type','$stage->sequence','$stage->ccid')";
       return $this->executeInsertQuery($sql);
	}
	
	public function updateItem($stage)
	{
        $sql="update $this->stageTable
                set stageName='$stage->stageName',
                type='$stage->type',
                sequence='$stage->sequence',
                ccid='$stage->ccid'
                where stageid='$stage->stageid'";
        return $this->executeQuery($sql);   
	}
    
    
    public function deleteItem($stage)
    {
       $sql="delete from $this->stageTable where stageid='$stage->stageid'";
       return $this->executeQuery($sql);   
    }

	public function getStages($customerQuery)
	{
		$connect=new Connection();
        $connection=$connect->getConnection();
        $dao=array();

        $sql="SELECT stageid,stageName,type,sequence,ccid FROM $this->stageTable";

        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }
	 
        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $dao[$index]=array('stageid'=>$row['stageid'],
                                        'stageName'=>$row['stageName'],
                                        'type'=>$row['type'],
                                        'sequence'=>$row['sequence'],
                                        'ccid'=>$row['ccid']
                                        );
                    $index++;
                }
            }
        }
        
        $connection->close();
        return $dao;
	}
}

?>
