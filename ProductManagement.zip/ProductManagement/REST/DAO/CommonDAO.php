<?php
require_once("Connect.php");

Class CommonDAO
{
    public $limit=100;
    public $costcenterTable="cost_center";
    public $stageTable="stage";
    public $productTable="product";
    public $rawMaterial="raw_material";
    public $matProdMapTable="mat_prod_map";
    public $productTransactionTable="product_transactions";
    public $userDetailsTable="user_details";

    public function verifyToken($api_key)
    {
        $connect=new Connection();
            $connection=$connect->getConnection();

         //   $sql="SELECT * FROM sethengineering.user_details where ApiKey='".$api_key."' and loginStatus='LOGGEDIN'";
        // this sql is for testing purpose only
         $sql="SELECT * FROM user_details where ApiKey='$api_key'";
        
            if($result = mysqli_query($connection,$sql))
            {
                if(mysqli_num_rows($result)>0)
                {
                    return "VALID";
                }
                else
                {
                    return NULL;
                }
            }
    }

    public function executeQuery($sql)
    {
        $connect=new Connection();
        $connection=$connect->getConnection();
        $res=false;
       
       if($result = mysqli_query($connection,$sql)){
         $res=$result;
       }
       
       $connection->close();
       return $res;
    }

    public function executeInsertQuery($sql)
    {
        $connect=new Connection();
        $connection=$connect->getConnection();
        $res=false;
       
       if($result = mysqli_query($connection,$sql)){
        return mysqli_insert_id($connection);
       }
       
       $connection->close();
       return $res;
    }

    public function fetchResult($sql)
    {
        $connect=new Connection();
        $connection=$connect->getConnection();
        $res=null;
       
       if($result = mysqli_query($connection,$sql))
       {
            $res=$result;
       }
       $connection->close();
       return $res;
    }
}

?>