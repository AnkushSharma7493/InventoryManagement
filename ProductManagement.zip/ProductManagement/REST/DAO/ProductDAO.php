<?php
require_once("Connect.php");
require_once("CommonDAO.php");
require_once("CostCenterDAO.php");
require_once("MaterialDAO.php");
require_once("MatProdMapDAO.php");

Class ProductDAO extends CommonDAO
{
	public function addItem($product)
	{
        $sql="insert into $this->productTable values(NULL,'$product->name','$product->ccid')";
        return  $this->executeInsertQuery($sql);
	}
	
	public function updateItem($product)
	{
        $sql="update $this->productTable
                set productname='$product->name',
                ccid='$product->ccid'
                where productid='$product->id'";
        return $this->executeQuery($sql);   
	}
    
    
    public function deleteItem($product)
    {
       $sql="delete from $this->productTable where productid='$product->id'";
       return $this->executeQuery($sql);   
    }

	public function getProducts($customerQuery)
	{
		$connect=new Connection();
        $connection=$connect->getConnection();
        $dao=array();

        $sql="SELECT productid,productname,ccid FROM $this->productTable";

        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }
	 
        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $dao[$index]=array('id'=>$row['productid'],
                                        'name'=>$row['productname'],
                                        'ccid'=>$row['ccid']
                                        );
                    $index++;
                }
            }
        }
        $connection->close();
        return $dao;
    }
    
    public function getProductView()
    {
        $index=0;
        $products = $this->getProducts(null);
        $CostCenterDAO=new CostCenterDAO(); 
        $materialDAO = new MaterialDAO();

        foreach($products as $i => $product) 
        {
            $cid=$products[$i]['ccid'];
            $pid=$products[$i]['id'];

            $CC_query="SELECT * FROM $this->costcenterTable where id=$cid";
            $temp=$CostCenterDAO->getCC($CC_query);

            foreach($temp as $te)
            {
                $products[$i]['ccname'] = $te['ccName'];
            }
            
            $sql="select *,m.materialQtyPerProduct as unit_weight from $this->productTable p join $this->matProdMapTable m on p.productid = m.productid join $this->rawMaterial r on m.materialid=r.materialid where p.productid=$pid";
            $products[$i]['materials'] =  $materialDAO->getMaterials($sql); 
          
        } 
        return $products;
    }

    public function addProductView($product)
    {
        $product->id=$this->addItem($product);
        $matProdMapDAO = new MatProdMapDAO();
        
        // add each material
        foreach($product->materials as $i => $material) {
            $mid=$product->materials[$i]->id;
            $munit=$product->materials[$i]->materialQtyPerProduct;
            $product->mapids[$i]=$matProdMapDAO->addItem($mid,$product->id,$munit);
        }
        return $product;
    }

    public function deleteProductView($product)
    {
        $this->deleteItem($product);
        $sql="delete from $this->matProdMapTable where productid=$product->id";
        return $this->executeQuery($sql);  
    }

    public function updateproductView($product)
    {
        if($this->updateItem($product))
        {
            // remove previous mapping
            $sql="delete from $this->matProdMapTable where productid=$product->id";
            $this->executeQuery($sql);  
            $matProdMapDAO = new MatProdMapDAO();

            // add each material
            foreach($product->materials as $i => $material) {
                $mid=$product->materials[$i]->id;
                // this name (unit_weight) was adjusted in getProductView fucntion, to use exiting get() of materilaDAO
                $munit=$product->materials[$i]->unit_weight; 
                $product->mapids[$i]=$matProdMapDAO->addItem($mid,$product->id,$munit);
            }
            return true;
        }
        else
        {
            return false;
        }
    }
}

?>


