<?php
require_once("Connect.php");
require_once("CommonDAO.php");

Class MaterialDAO extends CommonDAO
{
   public function addItem($material)
	{
        $sql="insert into $this->rawMaterial values(NULL,'$material->name','$material->shape',
        '$material->length','$material->width','$material->height','$material->radius',
        '$material->measurement_unit','$material->instock_unit','$material->unit_weight')";
        $material->id =  $this->executeInsertQuery($sql);
        return $material;
    }
    
	
	public function updateItem($material)
	{
        $sql="update $this->rawMaterial
                set materialname='$material->name',
                 shape='$material->shape',
                 width='$material->width',
                 height='$material->height',
                 length='$material->length',
                 radius='$material->radius',
                 instock_unit='$material->instock_unit',
                 unit_weight='$material->unit_weight',
                 measurement_unit='$material->measurement_unit'
                where materialid='$material->id'";
        return $this->executeQuery($sql);   
	}
    
    
    public function deleteItem($material)
    {
       $sql="delete from $this->rawMaterial where materialid='$material->id'";
       return $this->executeQuery($sql);   
    }

	public function getMaterials($customerQuery)
	{
		$connect=new Connection();
        $connection=$connect->getConnection();
        $dao=array();

        $sql="SELECT materialid,materialname,shape,length,width,height,radius,measurement_unit,instock_unit,unit_weight FROM $this->rawMaterial";
     
        if(!is_null($customerQuery))
        {
            $sql=$customerQuery;
        }

        if($result = mysqli_query($connection,$sql))
        {
            if(mysqli_num_rows($result)>0)
            {
                $index=0;
                while($row = mysqli_fetch_assoc($result))
                {
                    $dao[$index]=array('id'=>$row['materialid'],
                                        'name'=>$row['materialname'],
                                        'shape'=>$row['shape'],
                                        'length'=>$row['length'],
                                        'width'=>$row['width'],
                                        'height'=>$row['height'],
                                        'radius'=>$row['radius'],
                                        'measurement_unit'=>$row['measurement_unit'],
                                        'instock_unit'=>$row['instock_unit'],
                                        'unit_weight'=>$row['unit_weight']
                                        );
                    $index++;
                }
            }
        }
        $connection->close();
        return $dao;
       
	}
}

?>
