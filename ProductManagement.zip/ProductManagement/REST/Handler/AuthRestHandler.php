<?php
require_once("SimpleRest.php");
require_once("../DAO/UserDAO.php");
require_once("../Response/BaseResponse.php");
require_once("../Controller/FrontController.php");



		
class AuthRestHandler extends SimpleRest {

	public function login()
	{
		try{
			$json = file_get_contents('php://input');
			$request = json_decode($json);
			$userdao=new UserDAO();
			$dao = $userdao->getCredentails($request->name);
			$response = new BaseResponse();

			//$request->password=password_hash($request->password, PASSWORD_DEFAULT);

			if(!is_null($dao) && $request->password == $dao['password'])
			{
				$apiKey=$userdao->setLogin($request->name);
				$response->api_key=$apiKey;
				$response->role=$dao['role'];
				$response->status=$this->setResponseCode(200);
				$json = json_encode($response);
				echo $json;
				exit;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
				$json = json_encode($response);
				echo $json;
				exit;
			}
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
	  	}
	}

	public function logout()
	{
		try{
			$json = file_get_contents('php://input');
			$request = json_decode($json);
			$userdao =new UserDAO();
			$tokenizer = new FrontController();

			if($tokenizer->verifyToken($userdao,$request))
			{
				$userdao->setStatus($request->api_key,'LOGGEDOFF',$request->name);	
				$json = json_encode($this->setResponseCode(200));
				echo $json;
				exit;
			}
		}catch(Exception $e) {
		$json = json_encode($this->setResponse($e->getMessage()));
		echo $json;
		exit;
	  }
	}
}
?>





