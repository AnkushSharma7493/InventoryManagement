<?php
require_once("SimpleRest.php");
require_once("../DAO/ProductDAO.php");
require_once("../Response/BaseResponse.php");
require_once("../Response/Response.php");

Class ProductRestHandler extends SimpleRest
{ 
	function getItems($productdao,$request)  
	{
		try{
			$response = new Response();
		//	$dao = $productdao->getProducts(null);
		$dao = $productdao->getProductView();
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	function addItem($productdao,$request)
	{
		try{
			$response = new BaseResponse();
			
			if($dao=$productdao->addProductView($request->product))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function updateItem($productdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($productdao->updateproductView($request->product))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function deleteItem($productdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($productdao->deleteProductView($request->product))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

}

?>
