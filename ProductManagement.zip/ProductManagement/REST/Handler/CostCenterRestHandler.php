<?php
require_once("SimpleRest.php");
require_once("../DAO/CostCenterDAO.php");
require_once("../Response/BaseResponse.php");
require_once("../Response/Response.php");

Class CostCenterRestHandler extends SimpleRest
{ 
	function getItems($costCenterdao,$request)  
	{
		try{
			$response = new Response();
			$dao = $costCenterdao->getCostCenterView();
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	function addItem($costCenterdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($dao=$costCenterdao->addCostCenterView($request->costCenter))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
				$response->data=$dao;
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function updateItem($costCenterdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($costCenterdao->updateCostCenterView($request->costCenter))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function deleteItem($costCenterdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($costCenterdao->deleteCostCenterView($request->costCenter))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

}

?>
