<?php
require_once("SimpleRest.php");
require_once("../DAO/MaterialDAO.php");
require_once("../Response/BaseResponse.php");
require_once("../Response/Response.php");

Class MaterialRestHandler extends SimpleRest
{ 
	function getItems($materialdao,$request)  
	{
		try{
			$response = new Response();
			$dao = $materialdao->getMaterials(null);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	function addItem($materialdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($dao=$materialdao->addItem($request->material))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function updateItem($materialdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($materialdao->updateItem($request->material))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function deleteItem($materialdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($materialdao->deleteItem($request->material))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

}

?>
