<?php
require_once("SimpleRest.php");
require_once("../Response/BaseResponse.php");
require_once("../Response/Response.php");


Class ProductTransactionRestHandler extends SimpleRest
{ 
	public function getItems($prodTransdao,$request)  
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getProductTransactions(null);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
    }

    public function addItem($prodTransdao,$request)  
    {
        try{
			$response = new BaseResponse();
			
			if($dao=$prodTransdao->addItem($request->productTransaction))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
				$response->data=$dao;
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	public function SaleProducts($prodTransdao,$request)
	{	
		try{
			$response = new BaseResponse();
			
			if($dao=$prodTransdao->SaleProducts($request->productTransaction))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
				$response->data=$dao;
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function updateItem($prodTransdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($dao=$prodTransdao->updateItem($request->productTransaction))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
				$response->data=$dao;
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function deleteItem($materialdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($prodTransdao->deleteItem($request->productTransaction))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}


	
	public function getProductTransactionForInward($prodTransdao,$request)
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getProductTransactionForInward($request->cid);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}
	
	public function getProductTransactionForOutward($prodTransdao,$request)
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getProductTransactionForOutward($request->cid);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	public function getProductTransactionByState($prodTransdao,$request)
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getProductTransactionByState($request->cid,$request->stage);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}
	
	public function getMaxProcessID($prodTransdao,$request)
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getMaxProcessID();
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	public function getCompletedProcessID($prodTransdao,$request)
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getCompletedProcessID($request->cid);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	public function getProductTransactionByFilter($prodTransdao,$request)
	{
		try{
			$response = new Response();
		    $dao = $prodTransdao->getProductTransactionByFilters($request->cid,$request->pid,$request->sid,$request->startDate,$request->endDate);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}  

	public function getProductTransactionCount($prodTransdao,$request)
	{
		try{
			$response = new Response();
			$inhouse = $prodTransdao->getProductTransactionCount('INHOUSE');
			$inward = $prodTransdao->getProductTransactionCount('INWARD');
			$outward = $prodTransdao->getProductTransactionCount('OUTWARD');
			$completedCount = $prodTransdao->getFinishedCount();
			
			if(!is_null($inhouse) && !is_null($inward) && !is_null($outward))
			{
				$response->status=$this->setResponseCode(200);
				$response->inhouse=$inhouse;
				$response->inward=$inward;
				$response->outward=$outward;
				$response->completedCount=$completedCount;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	} 
}
?>