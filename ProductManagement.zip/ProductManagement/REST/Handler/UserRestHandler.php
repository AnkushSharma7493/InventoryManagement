<?php
require_once("SimpleRest.php");
require_once("../DAO/UserDAO.php");
require_once("../Response/Response.php");
require_once("../Response/BaseResponse.php");

Class UserRestHandler extends SimpleRest
{ 
	function getAllUsers($userdao,$request)  
	{
		try{
			$response = new Response();
			$dao = $userdao->getUsers(null);
			
			if(!is_null($dao))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		  }
	}

	function addNewUser($userdao,$request)
	{
		try{
			$response = new BaseResponse();
			$user=$request->user;

			if($dao=$userdao->addUser($user))
			{
				$response->status=$this->setResponseCode(200);
				$response->data=$dao;
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			$response->data=$dao;
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function updateUser($userdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($userdao->updateUser($request->user))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

	function deleteUser($userdao,$request)
	{
		try{
			$response = new BaseResponse();
			if($userdao->deleteUser($request->user))
			{
				$response->status=$this->setResponseCode(200);
			}
			else
			{
				$response->status=$this->setResponseCode(500);
			}
			
			$response->api_key=$request->api_key;
			$response->role=$request->role;
			$json = json_encode($response);
			echo $json;
			exit;
		}catch(Exception $e) {
			$json = json_encode($this->setResponse($e->getMessage()));
			echo $json;
			exit;
		}
	}

}

?>
