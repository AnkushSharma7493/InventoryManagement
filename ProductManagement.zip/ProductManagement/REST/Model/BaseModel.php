<?php

Class BaseModel {
	public $code;
    public $msg;
}

?>