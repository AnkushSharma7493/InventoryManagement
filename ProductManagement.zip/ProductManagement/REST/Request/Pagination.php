<?php
Class Pagination {

private $startIndex;
private $recordCount;

public function getStartIndex() {
    return $this->startIndex;
}
public function setStartIndex($startIndex) {
    this->startIndex = startIndex;
}
public function getRecordCount() {
    return this->recordCount;
}
public function setRecordCount(int recordCount) {
    this->recordCount = recordCount;
}
}
?>