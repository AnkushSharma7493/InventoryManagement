var dashboardControllers = angular.module('dashboardControllers', []);

dashboardControllers.controller('dashboardControllers', [
		'$scope',
		'$location',
		'$http',
		'InventoryService',
		function($scope, $location, $http, InventoryService) {

			$scope.page = "applicationForm";	
			$scope.formName = "ProductStatusTrack";
			$scope.passwordVisibleStatus = false;
			$scope.shapes=["Cylinder","Sphere", "Cuboid","Cube"];
			$scope.measurementUnits=["Meter","CentiMeter","MilliMeter"];
			$scope.reports=["Product","Material"];
			$scope.reportName="Product";
			$scope.quantity = [ "KG", "TONS" ];
			$scope.userRole = [ "ADMIN", "USER","EXECUTIVE" ];
			$scope.selectedPanel="Report";
			$scope.search={};
			$scope.postSaleDetails={};

			$scope.formView={
				productReport : true,
				userReport : true,
				ccReport : true,
				rmReport : true
			}
			
			// Report tabes and form models
			
			$scope.tempUser = {};
			$scope.costCenter = { stages : [ {} ] };
			$scope.rawMaterial = {};
			$scope.product = {	materials : [ {} ]	};
			$scope.searchableStage=[];

			/**
			 * initialise the application
			 */
			$scope.init = function() {
				$scope.adminView = "Report";
				$scope.getProducts();
				$scope.getMaterials();
				$scope.getCostCenters();
				$scope.getUsers();
				$scope.getTransactions();
			}


			// SET ACITVE DASHBOARD
			$scope.setDashboard = function(name) {
				$scope.adminView = name;
				$scope.selectedPanel=name;

				switch(name)
				{
					case "Report" 		: $scope.getTransactions();break;
					case "product" 		: $scope.getProducts();break;
					case "costCenter" 	: $scope.getCostCenters();break;
					case "rawMaterial" 	: $scope.getMaterials();break;
					case "user" 		: $scope.getUsers();break;
					case "postSale"		: $scope.getSoldProducts();break;
				}
			}
			

			$scope.getSoldProducts=function()
			{
				  $scope.request={};
				  $scope.request.api_key=$scope.loginUser.api_key;
				  $scope.request.role=$scope.loginUser.role;
				  $scope.request.cid="-1";
				  $scope.request.pid="-1";
				  $scope.request.sid="1";
				  $scope.request.startDate="-1";
				  $scope.request.endDate="-1";

				  $scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				  InventoryService.getTransactionByFilter($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI(); 
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								if(response.data.length>0)
								{
									$scope.soldProducts=response.data;
								}
								else
								{
									alert("No Sold Product Available !");
									$scope.setDashboard("Report");
								}
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});

			}

			$scope.back = function() {
				$scope.page = "applicationForm";
			}

			$scope.addUser = function() {
				//validation
				if($scope.tempUser.UserPassword == $scope.tempUser.password2 && $scope.tempUser.UserPassword.length>0 && $scope.tempUser.UserName.length>0)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.user=$scope.tempUser;

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.addUser($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;$.unblockUI(); 
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								alert("USER CREATED SUCCESSFULLLY ! ");
								$scope.users.push(response.data);
								$scope.formView.userReport=!$scope.formView.userReport;
							}
							else
							{	
								alert("USER NOT ADDED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}
			

			$scope.getUsers = function() {
				
				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.getUsers($scope.loginUser).then(
					function(response) {
						$scope.loadingStatus=false;$.unblockUI(); 
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.users=response.data;
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}


			$scope.updateUser = function(index) {
				//validation
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.user=$scope.users[index];

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.updateUser($scope.request).then(
					function(response) {$scope.loadingStatus=false;$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								alert("User Updated Successfully  !");
								$scope.toggleEnable(index,$scope.users)
							}
							else
							{	
								alert("USER NOT UPDATED ! SERVER ERROR ");
							}
						}
					});
			}

			
			
			$scope.deleteUser = function(index) {
				//validation
				var UserName = prompt("Write User Name !", null);
				if(UserName == $scope.users[index].UserName)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.user=$scope.users[index];

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.deleteUser($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.users.splice(index, 1);
								alert("User deleted Successfully  !");
							}
							else
							{	
								alert("USER NOT DELETED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}

			/************************************************************************************/
			//									COST CENTER
			/************************************************************************************/
			
			$scope.addCostCenter = function() {
				//validation
				if($scope.costCenter.ccName.length>0 && $scope.costCenter.stages.length>0)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.costCenter=$scope.costCenter;

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.addCostCenter($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.costCenters.push(response.data);
								$scope.formView.ccReport=!$scope.formView.ccReport;
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}


			$scope.updateCostCenter = function(index) {
				//validation
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.costCenter=$scope.costCenters[index];

					var validFlag=true;

					for(let i=0;i<$scope.request.costCenter.stages.length;i++)
					{
						if($scope.request.costCenter.stages[i].stageName==undefined && $scope.$scope.request.costCenter.stages[i].type==undefined)
						{
							alert("Validation Failed ! Please verify the new added stages");
							validFlag=false;
						}
						
						if($scope.request.costCenter.stages[i].stageid==undefined)
						{
							$scope.request.costCenter.stages[i].stageid=null;
							$scope.request.costCenter.stages[i].ccid=$scope.request.costCenter.ccid;
							$scope.request.costCenter.stages[i].sequence=i+1;
						}
					}

					if(validFlag)
					{
						$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
						InventoryService.updateCostCenter($scope.request).then(
							function(response) {
								$scope.loadingStatus=false;
								$.unblockUI();
								if(response==undefined || typeof(response)=="string")
								{
									alert("SERVER ERROR ! Contact system admin")
								}
								else{
									if(response.status.code==200)
									{
										alert("CostCenter Updated Successfully  !");
										$scope.toggleEnable(index,$scope.costCenters);
									}
									else
									{	
										alert("COST CENTER NOT ADDED ! SERVER ERROR ");
									}
								}
							});
					}	
			}

			$scope.deleteCostCenter = function(index) {
				//validation
				var CostCenterName = prompt("Write CostCenter Name !", null);
				if(CostCenterName == $scope.costCenters[index].ccName)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.costCenter=$scope.costCenters[index];

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.deleteCostCenter($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.costCenters.splice(index, 1);
								alert("Cost Center deleted Successfully  !");
							}
							else
							{	
								alert("COST CENTER NOT DELETED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}
			
			
			/************************************************************************************/
			//									PRODUCT
			/************************************************************************************/
			
			$scope.addProduct = function() {
				//validation
			try{
					var cid=$scope.product.ccname.ccid;;
					var cname=$scope.product.ccname.ccName;
					$scope.product.ccid=cid;
					$scope.product.ccname=cname;
				
				if($scope.product.name.length>0 && $scope.product.ccid!=undefined)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.product=$scope.product;

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.addProduct($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								for(let i=0;i<response.data.materials.length;i++)
								{
									response.data.materials[i].unit_weight=response.data.materials[i].materialQtyPerProduct;
								}

								$scope.products.push(response.data);
								$scope.formView.productReport=!$scope.formView.productReport;
							}
							else
							{	
								alert("PRODUCT NOT ADDED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}
			catch(e)
			{
				alert("SOMETHING WENT WRONG , PLEASE TRY AGAIN");
			}
			}

			

			$scope.updateProduct = function(index) {
				//validation and request object setting
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.products[index].ccname=$scope.products[index].ccname.ccName;
					
					for(let i=0;i<$scope.products[index].materials.length;i++)
					{
						var temp=$scope.products[index].materials[i].unit_weight;
						$scope.products[index].materials[i]=$scope.products[index].materials[i].name;
						$scope.products[index].materials[i].unit_weight=temp;
					}

					$scope.request.product=$scope.products[index];

					if($scope.products[index].ccname!=undefined)
					{
						$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
						InventoryService.updateProduct($scope.request).then(
							function(response) {
								scope.loadingStatus=false;
								$.unblockUI();
								if(response==undefined || typeof(response)=="string")
								{
									alert("SERVER ERROR ! Contact system admin")
								}
								else{
									if(response.status.code==200)
									{
										alert("Product Updated Successfully  !");
										$scope.toggleEnable(index,$scope.products);
									}
									else
									{	
										alert("PRODUCT NOT UPDATED ! SERVER ERROR ");
										$scope.toggleEnable(index,$scope.products);
									}
								}
							});
					}
					else
					{
						alert("ALL REQUIRED FIELDS NOT PROVIDED !");
						$scope.toggleEnable(index,$scope.products);
					}
					
			}

			$scope.deleteProduct = function(index) {
				//validation
				var name = prompt("Write CostCenter Name !", null);
				if(name == $scope.products[index].name)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.product=$scope.products[index];

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.deleteProduct($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.products.splice(index, 1);
								alert("Product deleted Successfully  !");
							}
							else
							{	
								alert("PRODUCT NOT DELETED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}
			
					
			/************************************************************************************/
			//									MATERIAL
			/************************************************************************************/
		

			$scope.addMaterial = function() {
				//validation
				
				if($scope.rawMaterial.name.length>0 && $scope.rawMaterial.shape.length>0)
				{
					
					if($scope.rawMaterial.radius==undefined) $scope.rawMaterial.radius=0;
					if($scope.rawMaterial.length==undefined) $scope.rawMaterial.length=0;
					if($scope.rawMaterial.width==undefined) $scope.rawMaterial.width=0;
					if($scope.rawMaterial.height==undefined) $scope.rawMaterial.height=0;
					
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.material=$scope.rawMaterial;

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.addMaterial($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.rawMaterials.push(response.data);
								$scope.formView.rmReport=!$scope.formView.rmReport;
							}
							else
							{	
								alert("MATERIAL NOT ADDED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}

		

			$scope.updateMaterial = function(index) {
				//validation
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.material=$scope.rawMaterials[index];

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.updateMaterial($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								alert("Material Updated Successfully  !");
								$scope.toggleEnable(index,$scope.rawMaterials);
							}
							else
							{	
								alert("MATERIAL NOT UPDATED ! SERVER ERROR ");
							}
						}
					});
			}

			$scope.deleteMaterial = function(index) {
				//validation
				var name = prompt("Write Material Name !", null);
				if(name == $scope.rawMaterials[index].name)
				{
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					$scope.request.material=$scope.rawMaterials[index];

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.deleteMaterial($scope.request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.rawMaterials.splice(index, 1);
								alert("Material deleted Successfully  !");
							}
							else
							{	
								alert("MATERIAL NOT DELETED ! SERVER ERROR ");
							}
						}
					});
				}
				else
				{
					alert("Validation failed, please enter correct input");
				}
			}
			

			//******************************************************************************************* */
			//**************************************Transaction Reports********************************** */
			//******************************************************************************************* */

			$scope.getTransactions=function()
			{
				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.getTransaction($scope.loginUser).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.transactions=response.data;
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}

			$scope.clearFilter=function()
			{
				$scope.search.cc="";
				$scope.search.stage="";
				$scope.search.product="";
			}

			// set products for search costcenter
			$scope.searchableProductForCC=function()
			{
				for(let i=0;i<$scope.costCenters.length;i++)
				{
					if($scope.costCenters[i].ccName==$scope.search.cc.ccName)
					{
						$scope.searchableProducts=$scope.costCenters[i].products;
							// assign search stages and append sales stage 
							angular.copy($scope.costCenters[i].stages,$scope.searchableStage);
						//$scope.searchableStage=$scope.costCenters[i].stages;
						$scope.searchableStage.push({
							"stageid": "1",
							"stageName": "SOLD",
							"type": "INHOUSE",
							"sequence": "RANDOM",
							"ccid": "0",
							"$$hashKey": "object:25"
						  });
						break;
					}
				}
			}

			//seaRCH TRANSACTION BASED ON FILTER

			$scope.searchTransaction=function()
			{
			//validation
			/*	if($scope.verifyEmpty($scope.search.cc) && $scope.verifyEmpty($scope.search.stage) && $scope.verifyEmpty($scope.search.product))
				{
					$scope.getTransactions();
				}*/
			
					$scope.request={};
					$scope.request.api_key=$scope.loginUser.api_key;
					$scope.request.role=$scope.loginUser.role;
					
					//if($scope.search.cc!=null && $scope.search.cc!="" && $scope.search.cc!=undefined)
					if($scope.verifyEmpty($scope.search.cc))
						$scope.request.cid=$scope.search.cc.ccid;
					else
						$scope.request.cid=-1;

					//if($scope.search.product!=null && $scope.search.product!="" && $scope.search.product!=undefined)
					if($scope.verifyEmpty($scope.search.product))
						$scope.request.pid=$scope.search.product.id;
					else
						$scope.request.pid=-1;

					//if($scope.search.stage!=null && $scope.search.stage!="" && $scope.search.stage!=undefined)
					if($scope.verifyEmpty($scope.search.stage))
						$scope.request.sid=$scope.search.stage.stageid;
					else
						$scope.request.sid=-1;

					$scope.request.startDate=-1;
					$scope.request.endDate=-1;

					$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
					InventoryService.getTransactionByFilter($scope.request).then(
						function(response) {
							$scope.loadingStatus=false;
							$.unblockUI();
							if(response==undefined || typeof(response)=="string")
							{
								alert("SERVER ERROR ! Contact system admin")
							}
							else{
								if(response.status.code==200)
								{
									$scope.transactions=response.data;
								}
								else
								{	
									alert(" SERVER ERROR ");
								}
							}
						});
					
			}



			$scope.updatePostSaleTransaction=function()
			{
				if(!$scope.verifyEmpty($scope.postSaleDetails.product.inquantity))
				{
					$scope.postSaleDetails.product.inquantity="";
				}
				if(!$scope.verifyEmpty($scope.postSaleDetails.product.outquantity))
				{
					$scope.postSaleDetails.product.outquantity="";
				}
				if(!$scope.verifyEmpty($scope.postSaleDetails.product.gatepass))
				{
					$scope.postSaleDetails.product.gatepass="";
				}
				if(!$scope.verifyEmpty($scope.postSaleDetails.product.Challan))
				{
					$scope.postSaleDetails.product.Challan="";
				}
				
				var request={};
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.productTransaction={};
				request.productTransaction.inquantity=$scope.postSaleDetails.product.inquantity;
				request.productTransaction.outquantity=$scope.postSaleDetails.product.outquantity;
				request.productTransaction.gatepass=$scope.postSaleDetails.product.gatepass;
				request.productTransaction.Challan=$scope.postSaleDetails.product.Challan;
				request.productTransaction.builty=$scope.postSaleDetails.builty
				request.productTransaction.transporter=$scope.postSaleDetails.transporter
				request.productTransaction.courierNo=$scope.postSaleDetails.courierNo;
				request.productTransaction.courierVendor=$scope.postSaleDetails.courierVendor;
				request.productTransaction.transid=$scope.postSaleDetails.product.transid;

				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'});
				InventoryService.updateTransaction(request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin");
						}
						else{
							if(response.status.code==200)
							{
								alert("Transaction Updated Successfully");
								$scope.resetPostForm();
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
				}

				// update report transctions detials
				$scope.updateReportTransaction=function(index)
				{
					var request={};
					request.api_key=$scope.loginUser.api_key;
					request.role=$scope.loginUser.role;
					request.productTransaction=$scope.transactions[index];

					$scope.loadingStatus=true;
					$.blockUI({ message: 'loading . . .'});
					InventoryService.updateTransaction(request).then(
						function(response) {
							$scope.loadingStatus=false;
							$.unblockUI();
							if(response==undefined || typeof(response)=="string")
							{
								alert("SERVER ERROR ! Contact system admin");
							}
							else{
								if(response.status.code==200)
								{
									alert("Transaction Updated Successfully");
									$scope.toggleEnable(index,$scope.transactions);
								}
								else
								{	
									alert(" SERVER ERROR ");
								}
							}
						});
				}


		
			$scope.resetPostForm=function()
			{
				$scope.postSaleDetails.builty="";
				$scope.postSaleDetails.transporter="";
				$scope.postSaleDetails.courierNo="";
				$scope.postSaleDetails.courierVendor="";
			}

			// init
			$scope.init();

		} ]);

