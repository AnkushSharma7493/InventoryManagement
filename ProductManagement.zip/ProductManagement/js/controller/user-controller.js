var userControllers = angular.module('userControllers', []);

userControllers.controller('userControllers', [
		'$scope',
		'$location',
		'$http',
		'InventoryService',
		function($scope, $location, $http, InventoryService) {

			$scope.selected={};
			$scope.productTransaction={};
			$scope.costCenterStages=[];
			$scope.maxProcessID;
			$scope.temp={
				Weight:0,
				tempUnits:0
			}
			
			
			$scope.init=function(){
				$scope.userView="home";
				$scope.loadTransactionCount()
			}

			$scope.loadTransactionCount=function()
			{
				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.getTransactionCount($scope.loginUser).then(
					function(data) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(data.status.code==200)
						{
							$scope.inwardCount=data.inward[0].count;
							$scope.outwardCount=data.outward[0].count;
							$scope.dailyProductionCount=data.inhouse[0].count;
							$scope.completedCount=data.completedCount[0].count;
						}
						else
						{
							console.log("SERVER ERROR , WHILE COLLECTING ACTIVE TRANSACTION COUNT");
						}
					});
			}

			
		
			$scope.setDashboard = function(name,data) {
				$scope.userView = name;
				$scope.loadTransactionCount();
				switch(name)
				{
					case "dailyProduction" : $scope.getCostCenters(); 
											 $scope.getProducts(); 
											//$scope.generateProcessID(); 
											if($scope.costCenters.length==0)
											{
												$scope.setDashboard('home');
											}
											break;
					case "stage" : 			$scope.transactionPreProcessor(data);
											break;
					case "transaction" : 	$scope.getProductsByStage(data);
											$scope.selected.stage=data;
											break;
					case "inward"		:	$scope.count.returnableCount=$scope.inwardCount;
											$scope.getMaterials();	
											break;
					case "outward"		:	$scope.count.	returnableCount=$scope.outwardCount;
											$scope.count.nonReturnableCount=$scope.completedCount;
											break;
				}
			}

			$scope.setNestedDashboard=function(name)
			{
				$scope.userView = $scope.userView+name;
				if($scope.userView!="inwardNonReturnable")
				{
					$scope.productTransaction={};
					$scope.getCostCenters();
				}
			}
			
			$scope.transactionPreProcessor=function(costcenter)
			{
			//filter product for selected cost center where material.length>0
				$scope.stageProducts=[];
				$scope.costCenterStages=[];
				$scope.selected.CostCenter=costcenter;
				
				for(let i=0;i<$scope.costCenters.length;i++)
				{
					if($scope.costCenters[i].ccName==costcenter.ccName)
					{
						// assign cost center stages
						for(let n=0;n<$scope.costCenters[i].stages.length;n++)
						{
							if($scope.costCenters[i].stages[n].type =='INHOUSE' )
							{
								var stage = $scope.costCenters[i].stages[n];
								stage.mode="COUNT";
								$scope.getProductsByStage(stage);
								$scope.costCenterStages.push(stage);
							}
						}


						for(let j=0;j<$scope.costCenters[i].products.length;j++)
						{
							for(let k=0;k<$scope.products.length;k++)
							{
								if($scope.costCenters[i].products[j].name==$scope.products[k].name)
								{
									if($scope.products[k].materials.length>0)
									{
										$scope.stageProducts.push($scope.products[k]);
									}
									break; // require product found
								}
							}
						}
						break; // required cost center found
					}
				}
			}



			$scope.loadOutwarReturnabledProduct=function()
			{
				var request={};
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.cid=$scope.productTransaction.cc.ccid;

				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.getOutwardTrans(request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else
						{
							if(response.status.code==200)
							{
								if(response.data.length==0)
								{
									alert("NO PRODUCT AVAILABLE IN OUTWARD FOR "+$scope.productTransaction.cc.ccName);
									$scope.setDashboard('home');
								}
								else{
									$scope.stageProducts=response.data;
								}
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}

			$scope.loadCompletedProduct=function()
			{
				var request={};
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.cid=$scope.productTransaction.cc.ccid;

				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.getCompletedTrans(request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else
						{
							if(response.status.code==200)
							{
								if(response.data.length==0)
								{
									alert("NO COMPLETED PRODUCT AVAILABLE for "+$scope.productTransaction.cc.ccName);
									$scope.setDashboard('home');
								}
								else{
									$scope.stageProducts=response.data;
								}
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}


			$scope.loadInwarReturnabledProduct=function()
			{
				var request={};
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.cid=$scope.productTransaction.cc.ccid;

				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.getInwardTrans(request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else
						{
							if(response.status.code==200)
							{
								if(response.data.length==0)
								{
									alert("NO PRODUCT AVAILABLE IN INWARD FOR "+$scope.productTransaction.cc.ccName);
									$scope.setDashboard('home');
								}
								else{
									$scope.stageProducts=response.data;
								}
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}

			// process transaction
			
			$scope.costCenterPostProcessor=function()
			{
					if($scope.selected.stage==undefined)
					{
						$scope.startProcessTransaction();
					}
					else
					{
						$scope.processTransaction();
					}

					$scope.productTransaction={};
			}

			
			// calculate the next stage from current
			$scope.getNextState=function(sequence)
			{
				var CostCenter = $scope.selected.CostCenter;

				if(CostCenter.stages[CostCenter.stages.length-1].sequence==sequence)
				{
					return CostCenter.stages[sequence-1].stageid;
				}
				else
				{
					sequence++;
				}
				
				for(let i=0;i<CostCenter.stages.length;i++)
				{
					if(CostCenter.stages[i].sequence==sequence)
					{
						return CostCenter.stages[i].stageid;
					}
				}
			}
			// calculate the next stage from current
			$scope.getNextStatev1=function(CostCenter,sequence,count)
			{
				if(CostCenter.stages[CostCenter.stages.length-1].sequence==sequence)
				{
					return CostCenter.stages[sequence-1].stageid;
				}
				else
				{
					for(let j=0;j<count;j++)
					{
						sequence++;
					}
					
					for(let i=0;i<CostCenter.stages.length;i++)
					{
						if(CostCenter.stages[i].sequence==sequence)
						{
							return CostCenter.stages[i].stageid;
						}
					}
				}
			}

			$scope.startProcessTransaction=function()
			{
				// validation
				if($scope.productTransaction.product!=undefined && $scope.productTransaction.quantity!=undefined)
				{
					$scope.errorFlag=false;
					var request={};
					request.api_key=$scope.loginUser.api_key;
					request.role=$scope.loginUser.role;
					request.productTransaction={};
					request.productTransaction.processid=0;
					request.productTransaction.productid=$scope.productTransaction.product.id;
					request.productTransaction.ccid=$scope.selected.CostCenter.ccid;	
					request.productTransaction.stateid=$scope.selected.CostCenter.stages[0].stageid;
					request.productTransaction.outquantity="0";
					request.productTransaction.inquantity=$scope.productTransaction.quantity;
					request.productTransaction.Challan="0";
					request.productTransaction.gatepass="0";
					request.productTransaction.transid=0;
					request.productTransaction.status="INPROGRESS";
				
					$scope.saveTransaction(request);
				}
				else
				{
					$scope.errorFlag=true;
					$scope.errorMsg="Form Validation Failed !";
				}
			}

			$scope.processTransaction=function()
			{	
				if(parseInt($scope.productTransaction.quantity)<=parseInt($scope.productTransaction.product.inquantity))
				{
				var request={};
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.productTransaction={};
				request.productTransaction.processid=$scope.productTransaction.product.processid;
				request.productTransaction.productid=$scope.productTransaction.product.productid;
				request.productTransaction.ccid=$scope.selected.CostCenter.ccid;	
				
				// calculate next satage if here to save into db
				request.productTransaction.stateid=$scope.getNextState($scope.selected.stage.sequence);
				request.productTransaction.outquantity=$scope.productTransaction.quantity;
				request.productTransaction.inquantity=$scope.productTransaction.product.inquantity;
				request.productTransaction.Challan="0";
				request.productTransaction.gatepass="0";
				request.productTransaction.transid=$scope.productTransaction.product.transid;
				

				if($scope.selected.CostCenter.stages[$scope.selected.CostCenter.stages.length-1].sequence!=$scope.selected.stage.sequence)
				{
					
					request.productTransaction.status="INPROGRESS"
				}
				else
				{
					request.productTransaction.status="COMPLETE"
				}


				// calculate next 
				
				$scope.saveTransaction(request);
			}
			else
			{
				alert("Validation Faled, processed unit cannot be greater than input unit");
			}
			}

			$scope.processInWardTransaction=function()
			{
				if(parseInt($scope.productTransaction.quantity)<=parseInt($scope.productTransaction.product.inquantity) && $scope.productTransaction.quantity!=undefined && $scope.productTransaction.challanNo!=undefined && $scope.productTransaction.gatePass!=undefined)
				{
				$scope.errorFlag=false;	
				var request={}
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.productTransaction={};
				request.productTransaction.processid=$scope.productTransaction.product.processid;
				request.productTransaction.productid=$scope.productTransaction.product.productid;
				request.productTransaction.ccid=$scope.productTransaction.cc.ccid;	
				request.productTransaction.stateid=$scope.getNextState($scope.productTransaction.product.sequence);
				request.productTransaction.outquantity=$scope.productTransaction.quantity;
				request.productTransaction.inquantity=$scope.productTransaction.product.inquantity;
				request.productTransaction.Challan=0
				request.productTransaction.gatepass=0;
				request.productTransaction.transid=$scope.productTransaction.product.transid;
				
				if($scope.selected.CostCenter.stages[$scope.selected.CostCenter.stages.length-1].sequence!=$scope.productTransaction.product.sequence)
				{
					
					request.productTransaction.status="INPROGRESS"
				}
				else
				{
					request.productTransaction.status="COMPLETE"
				}
				
				$scope.saveTransaction(request);
				}
				else
				{
					$scope.errorFlag=true;
					$scope.errorMsg="Form Validation Failed !";
				}
			}


			$scope.processOutWardTransaction=function()
			{
				if(parseInt($scope.productTransaction.quantity)<=parseInt($scope.productTransaction.product.inquantity) && $scope.productTransaction.quantity!=undefined && $scope.productTransaction.challanNo!=undefined && $scope.productTransaction.gatePass!=undefined)
				{
				$scope.errorFlag=false;
				var request={}
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.productTransaction={};
				request.productTransaction.processid=$scope.productTransaction.product.processid;
				request.productTransaction.productid=$scope.productTransaction.product.productid;
				request.productTransaction.ccid=$scope.productTransaction.cc.ccid;	
				request.productTransaction.stateid=$scope.getNextState($scope.productTransaction.product.sequence);
				request.productTransaction.outquantity=$scope.productTransaction.quantity;
				request.productTransaction.inquantity=$scope.productTransaction.product.inquantity;
				request.productTransaction.Challan=$scope.productTransaction.challanNo;
				request.productTransaction.gatepass=$scope.productTransaction.gatePass;
				request.productTransaction.transid=$scope.productTransaction.product.transid;
				if($scope.selected.CostCenter.stages[$scope.selected.CostCenter.stages.length-1].sequence!=$scope.productTransaction.product.sequence)
				{
					
					request.productTransaction.status="INPROGRESS"
				}
				else
				{
					request.productTransaction.status="COMPLETE"
				}
				$scope.saveTransaction(request);
				}
				else
				{
					$scope.errorFlag=true;
					$scope.errorMsg="Form Validation Failed !";
				}
			}
			

			
			$scope.saveTransaction=function(request)
			{
				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.ProcessTrans(request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin");
						}
						else
						{
							if(response.status.code==200)
							{
								alert("Submit Successfull !");
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
						$scope.setDashboard('home');	
					});
			}
		
			$scope.soldTransaction=function(request)
			{
				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.soldProduct(request).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin");
						}
						else
						{
							if(response.status.code==200)
							{
								alert("Submit Successfull !");
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
						$scope.setDashboard('home');	
					});
			}

		$scope.getProductsByStage=function(stage)
		{
			if(stage!=undefined)
			{		
			var request={};
			request.api_key=$scope.loginUser.api_key;
			request.role=$scope.loginUser.role;
			request.stage=stage.stageid;
			request.cid=$scope.selected.CostCenter.ccid;


			$scope.loadingStatus=true;
			$.blockUI({ message: 'loading . . .'});
			InventoryService.getTransByStage(request).then(
				function(response) {
					$scope.loadingStatus=false;
					$.unblockUI();
					if(response==undefined || typeof(response)=="string")
					{
						alert("SERVER ERROR ! Contact system admin")
					}
					else
					{
						if(response.status.code==200)
						{
							if(stage.mode=="COUNT")
							{
								stage.productCount=response.data.length;	
								stage.mode="DATA";
							}
							else
							{
								if(response.data.length==0)
								{
									alert("NO PRODUCT AVAILABLE IN "+stage.stageName);
									$scope.setDashboard('home');
								}
							
								$scope.stageProducts=response.data;
							}
						}
						else
						{	
							alert(" SERVER ERROR ");
						}
					}
				});
			}
		}

		$scope.processSaleTransaction=function()
		{
			if(parseInt($scope.productTransaction.product.outquantity)>=parseInt($scope.productTransaction.quantity) && $scope.verifyEmpty($scope.productTransaction.billNo)  && $scope.verifyEmpty($scope.productTransaction.gatePass))
			{
				var request={};
				request.api_key=$scope.loginUser.api_key;
				request.role=$scope.loginUser.role;
				request.productTransaction={};
				request.productTransaction.processid=$scope.productTransaction.product.processid;
				request.productTransaction.productid=$scope.productTransaction.product.productid;
				request.productTransaction.ccid=$scope.productTransaction.cc.ccid;
				// calculate next satage if here to save into db
				request.productTransaction.outquantity=$scope.productTransaction.quantity;
				request.productTransaction.inquantity=$scope.productTransaction.product.outquantity;
				request.productTransaction.billNumber=$scope.productTransaction.billNo;
				request.productTransaction.gatepass=$scope.productTransaction.gatePass;
				request.productTransaction.transid=$scope.productTransaction.product.transid;
				request.productTransaction.status="SOLD"

				// calculate next 				
				$scope.soldTransaction(request);
			}
			else
			{
				alert("validation failed");
			}
		}

		// add material stock
		$scope.addMaterialStock=function()
		{
			var request={};
			request.api_key=$scope.loginUser.api_key;
			request.role=$scope.loginUser.role;
			request.material={};
			request.material.id=$scope.selected.material.id;
			request.material.height=$scope.selected.material.height;
			request.material.instock_unit=eval($scope.selected.material.instock_unit+"+"+$scope.temp.Units);
			request.material.length=$scope.selected.material.length;
			request.material.measurement_unit=$scope.selected.material.measurement_unit;
			request.material.name=$scope.selected.material.name;
			request.material.radius=$scope.selected.material.radius;
			request.material.shape=$scope.selected.material.shape;
			request.material.unit_weight=$scope.selected.material.unit_weight;
			request.material.width=$scope.selected.material.width;

			$scope.loadingStatus=true;
			$.blockUI({ message: 'loading . . .'});
			InventoryService.updateMaterial(request).then(
				function(response) {
					$scope.loadingStatus=false;
					$.unblockUI();
					if(response==undefined || typeof(response)=="string")
					{
						alert("SERVER ERROR ! Contact system admin")
					}
					else{
						if(response.status.code==200)
						{
							alert("Material Stock Updated Successfully  !");
						}
						else
						{	
							alert("MATERIAL NOT UPDATED ! SERVER ERROR ");
						}
					}
			});

			$scope.setDashboard('home');
		}

		// convert unit to weight
		$scope.convertWeight=function()
		{
			$scope.temp.Weight=$scope.selected.material.unit_weight*$scope.temp.Units;
			console.log($scope.temp.Weight);
		}

		$scope.convertUnit=function()
		{
			$scope.temp.Units=$scope.temp.Weight/$scope.selected.material.unit_weight;
			console.log($scope.temp.Units);
		}
			
			$scope.init();
			
		} ]);

