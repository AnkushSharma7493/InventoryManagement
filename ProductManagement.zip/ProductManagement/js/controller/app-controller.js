var appControllers = angular.module('appControllers', []);

appControllers.controller('appControllers', [
		'$scope',
		'$location',
		'$http',
		'InventoryService',
		function($scope, $location, $http, InventoryService) {
			$scope.loginUser={};
			$scope.alertErrorMsg;
			$scope.error = false;
			$scope.users=[];
			$scope.costCenters=[];
			$scope.products =[];
			$scope.rawMaterials =[];
			$scope.transactions=[];
			$scope.inwardCount=0;
			$scope.outwardCount=0;
			$scope.dailyProductionCount=0;
			$scope.loadingStatus=false;
			$scope.userView="home";
			$scope.count={
				nonReturnableCount:0,
				returnableCount:0
			};

			$scope.init=function()
			{}

			$scope.logout=function()
			{
				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.logout($scope.loginUser).then(
					function(data) {
						$scope.loadingStatus=false;
						$.unblockUI();
						if(data.code==200)
						{
							$scope.loginUser={};
							$location.path('/');
						}
						else
						{
							alert("LOGGED OUR FAILED! CONTACT SYSTEM ADMIN");
						}
					});
			}

			$scope.getCostCenters = function() 
			{	
				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'}); 				
				InventoryService.getCostCenters($scope.loginUser).then(
					function(response) {
						$scope.loadingStatus=false;
						$.unblockUI(); 	
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								if(response.data.length>0)
								{
									$scope.costCenters=response.data;
								}
								else
								{
									alert("NO COST CENTER AVAILABLE");
								}
							}

							else
							{	
								alert("COST CENTER NOT ADDED ! SERVER ERROR ");
							}
						}
					});
			}
			
			$scope.getProducts = function() {
				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'}); 				
				InventoryService.getProducts($scope.loginUser).then(
					function(response) {
						$scope.loadingStatus=false;$.unblockUI(); 	
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.products=response.data;
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}

			$scope.getMaterials = function() {
				$scope.loadingStatus=true;$.blockUI({ message: 'loading . . .'}); 				
				InventoryService.getMaterials($scope.loginUser).then(
					function(response) {
						$scope.loadingStatus=false;$.unblockUI(); 	
						if(response==undefined || typeof(response)=="string")
						{
							alert("SERVER ERROR ! Contact system admin")
						}
						else{
							if(response.status.code==200)
							{
								$scope.rawMaterials=response.data;
								$scope.getMaterialCount();
							}
							else
							{	
								alert(" SERVER ERROR ");
							}
						}
					});
			}

			$scope.getMaterialCount=function()
			{
				//$scope.nonReturnableCount=0;
				$scope.count.nonReturnableCount=0;
				for(let i=0;i<$scope.rawMaterials.length;i++)
				{
					$scope.count.nonReturnableCount=eval($scope.rawMaterials[i].instock_unit+"+"+$scope.count.nonReturnableCount);
				}
			}
			
			// Delete table row
			$scope.deleteRow = function(index, array) {
				var name = prompt("Write Name !", null);
				if (name == array[index].name) {
					array.splice(index, 1);
				}
			}
			// add item
			$scope.addItem=function(item,array){
					array.push(item);
			}

			// toggle row enable
			$scope.toggleEnable = function(index, array) {
				if (array[index].disable == undefined) {
					array[index].disable = false;
				} else {
					array[index].disable = !array[index].disable;
				}
			}		

			// add empty object
			$scope.addelement = function(array) {
				array.push({});
			}

			// add empty object
			$scope.removeElement = function(array,index) {
				array.splice(index,1);
			}

			// return true if element is not empty
			$scope.verifyEmpty=function(data)
			{
				if(data!=undefined && data!="" && data!=null)
				{
					return true;
				}
				else
				{
					return false;
				}
			}

			$scope.init();

		}]);