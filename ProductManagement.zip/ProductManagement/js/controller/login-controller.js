var loginControllers = angular.module('loginControllers', []);

loginControllers.controller('loginControllers', [
		'$scope',
		'$location',
		'$http',
		'InventoryService',
		function($scope, $location, $http, InventoryService) {
			$scope.credentials = {};
			
			// Login to application, verify role
			$scope.login = function() {
				
				//$.blockUI({ overlayCSS: { backgroundColor: '#00f' } }); 
				//$.blockUI({ message: '<img style="height:100px;width:100px;" src="Resource/img/loading.gif" />'}); 
				//	$.blockUI({ overlayCSS: { backgroundColor: '#00a' },message: 'loading . . .'});
				$scope.loadingStatus=true;
				$.blockUI({ message: 'loading . . .'});
				InventoryService.login($scope.credentials).then(
					function(data) {
						$scope.loadingStatus=false;
						$.unblockUI;
						if(data==undefined || typeof(data)=="string")
						{
							alert("LOGIN FAILED ! PROVIDE CORRECT CREDENTIALS");
						}
						else{
							if(data.status.code==200)
							{
								$scope.loginUser.name=$scope.credentials.name;
								$scope.loginUser.role=data.role;
								$scope.loginUser.api_key=data.api_key;
								
								if ($scope.loginUser.role == 'ADMIN') {
									$location.path('/adminDashboard');
								} else if ($scope.loginUser.role == 'USER') {
									$location.path('/userDashboard');
								} else if ($scope.loginUser.role == 'EXECUTIVE') {
									$location.path('/executiveDashboard');
								}
							}
							else
							{
								alert("LOGIN FAILED ! PROVIDE CORRECT CREDENTIALS");	
							}
						}
					});
				//	blockUI.stop();
			}
			
		} ]);