'use strict';

var SethApp = angular.module('SethApp', [ 'dashboardControllers','loginControllers','userControllers','appControllers', 'InventoryService', 'ngRoute' ]);

SethApp.config([ '$routeProvider', '$locationProvider',
		function($routeProvider, $locationProvider) {
			$locationProvider.hashPrefix('');

			$routeProvider.when("/", {
				templateUrl : 'partials/login.html',
				 controller: 'loginControllers'
			}).when("/login", {
				templateUrl : 'partials/login.html',
				controller: 'loginControllers'
			}).when("/adminDashboard", {
				templateUrl : 'partials/AdminForms/AdminDashboard.html',
				controller: 'dashboardControllers'
			}).when("/executiveDashboard", {
				templateUrl : 'partials/AdminForms/ExecutiveDashboard.html',
				controller: 'dashboardControllers'
			}).when("/userDashboard", {
				    templateUrl : 'partials/UserForms/UserDashboard.html',
				    controller: 'userControllers'
			}).otherwise({
				redirectTo : "/"
			})
		} ]);
