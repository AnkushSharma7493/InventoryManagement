'use strict';

var InventoryService = angular.module('InventoryService', []);
InventoryService.service('InventoryService', function($http, $q) {

	//var baseUrl='http://localhost/ProductManagement/REST/';
	var baseUrl='REST/';
	
	
	return {
		login : login,
		logout : logout,

		addUser : addUser,
		getUsers : getUsers,
		updateUser : updateUser,
		deleteUser : deleteUser,
		
		addProduct : addProduct,
		getProducts : getProducts,
		updateProduct : updateProduct,
		deleteProduct : deleteProduct,
		
		addCostCenter : addCostCenter,
		getCostCenters : getCostCenters,
		updateCostCenter : updateCostCenter,
		deleteCostCenter : deleteCostCenter,
		
		addMaterial : addMaterial,
		getMaterials : getMaterials,
		updateMaterial : updateMaterial,
		deleteMaterial : deleteMaterial,

		getTransaction : getTransaction,
		getInwardTrans : getInwardTrans,
		getOutwardTrans : getOutwardTrans,
		getTransByStage : getTransByStage,
		getCompletedTrans : getCompletedTrans,
		ProcessTrans : ProcessTrans,
		getTransactionByFilter : getTransactionByFilter,
		
		soldProduct : soldProduct,
		updateTransaction : updateTransaction,
		getTransactionCount : getTransactionCount
	};

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Login  
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function login(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/login/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Logout
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function logout(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/logout/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Add User
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function addUser(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/user/add/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Get Users
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getUsers(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/user/list/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Update Users
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function updateUser(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/user/update/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Delete Users
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function deleteUser(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/user/delete/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Add Product
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function addProduct(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/add/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Get Products
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getProducts(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/list/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Update Products
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function updateProduct(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/Product/update/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Delete Products
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function deleteProduct(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/Product/delete/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}


	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Add Cost Center
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function addCostCenter(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/cc/add/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Get CostCenter
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getCostCenters(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/cc/list/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Update CostCenter
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function updateCostCenter(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/cc/update/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Delete CostCenter
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function deleteCostCenter(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/cc/delete/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Add Material
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function addMaterial(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/material/add/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Get Material
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getMaterials(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/material/list/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Update Material
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function updateMaterial(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/material/update/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Delete Material
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function deleteMaterial(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/material/delete/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	


	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Read Transaction
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getTransaction(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/list/',
			cache : false
		});
		
		return request.then(handleSuccess, handleError);
	}


	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Read INWARD Transaction
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getInwardTrans(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/list/in/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}	

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Read OUTWARD Transaction
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getOutwardTrans(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/list/out/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}	


	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Read Completed Transaction
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getCompletedTrans(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/list/completed/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Process Transaction
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function ProcessTrans(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/add/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//  Transaction BY STAGE
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getTransByStage(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/list/stage/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	function getTransactionByFilter(req)
	{
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/list/filters/',
			cache : false
		});
		
		return request.then(handleSuccess, handleError);
	}
		
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//  Transaction BY STAGE
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function soldProduct(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/sale/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	function updateTransaction(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/update/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}

	function getTransactionCount(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'sethi/product/trans/count/',
			cache : false
		});

		return request.then(handleSuccess, handleError);
	}
	
	function handleSuccess(response) {
		return response.data;
	}

	function handleError(response) {
		return response.data;
	}

	
})